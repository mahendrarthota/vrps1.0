package ourproject;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SearchServlet
 */
@WebServlet("/SearchServlet")
public class SearchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

			/**
			 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
			 */
				// TODO Auto-generated method stub
			String name=request.getParameter("ename");
			String name1=request.getParameter("name1");
			response.setContentType("text/html");
			EmployeeDAO sr=new EmployeeDAO();
			PrintWriter out=response.getWriter();
			if(name1.equals("Email"))
			{
				
				Employee e=sr.getByIdentity(name);
				
				out.print("<table border='2' width='500' align='center' height='100' style='postion:relative;margin-top:100px;'>");
				out.println("<tr>");
				out.println("<td>"+e.getName()+"</td>");
				out.println("<td>"+e.getUserName()+"</td>");
				
				out.println("<td>"+e.getEmail()+"</td>");
			
			out.println("<td>"+e.getPhone()+"</td>");
			out.println("</tr></table>");
		
			}
			if(name1=="Reference id") {
				
				
			}
			if(name1=="phone") {
				
			}
			
			if(name1=="Name") {
				
			}
			if(name1=="Fresher"){

				
			}		
	}

		

	}


